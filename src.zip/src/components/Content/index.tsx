"use client";

import { categories, Ranks, Coins } from "@/src/data/store";
import RanksCard from "@/src/components/PackageCard/RanksCard";
import CoinsCard from "@/src/components/PackageCard/CoinsCard";

const Content = ({ category }: { category: string }) => {
  const currentCategory = categories.find(
    (cat) => cat.slug === category
  );

  let data: any[] = [];
  let CardComponent: any = null;

  if (category === "ranks") {
    data = Ranks;
    CardComponent = RanksCard;
  }

  if (category === "coins") {
    data = Coins;
    CardComponent = CoinsCard;
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-blue-400">
        {currentCategory?.name}
      </h2>

      {data.length === 0 ? (
        <p className="text-zinc-400">No packages available.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.map((pkg) => (
            <CardComponent key={pkg.id} pkg={pkg} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Content;
